java -cp ~/opt/grinder/lib/grinder.jar net.grinder.Console
